resource.AddFile ("materials/models/inline4/inline4_bellhousing_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_bellhousing_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_block_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_block_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_exhaustmanifold_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_exhaustmanifold_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_exhaustpipe_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_exhaustpipe_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_intake_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_intake_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_intakefront_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_intakefront_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_pully_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_pully_texture.vtf")

resource.AddFile ("materials/models/inline4/inline4_valvecover_texture.vmt")
resource.AddFile ("materials/models/inline4/inline4_valvecover_texture.vtf")


resource.AddFile ("models/inline4/inline4_engineblock.mdl")